<?php
$_['heading_title'] = 'Domitai for Opencart';
 
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';

$_['test_enable'] = "Yes";
$_['test_disable'] = "No";
$_['text_domitai'] = '<a href="https://domitai.com/" target="_blank"><img style="width:50px" src="https://domitai.com/assets/img/android-icon-144x144.png" alt="Domitai" title="Domitai"></a>';

 
$_['title'] = 'Title';
$_['description'] = 'Description';
$_['point_of_sale'] = "Domitai's point of sale";
$_['testnet'] = "Enable testnet";
 
$_['entry_status'] = 'Status:';
$_['entry_order_status'] = 'Order Status:';
 
$_['help'] = 'Point of sale created in your domitai account';

$_['text_button_save'] = 'Save';
$_['text_button_cancel'] = 'Cancel';
?>