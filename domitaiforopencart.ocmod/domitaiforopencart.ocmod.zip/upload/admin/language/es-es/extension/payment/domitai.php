<?php
$_['heading_title'] = 'Domitai para Opencart';
 
$_['text_enabled'] = 'Activado';
$_['text_disabled'] = 'Desactivado';

$_['test_enable'] = "Si";
$_['test_disable'] = "No";
$_['text_domitai'] = '<a href="https://domitai.com/" target="_blank"><img style="width:50px" src="https://domitai.com/assets/img/android-icon-144x144.png" alt="Domitai" title="Domitai"></a>';

 
$_['title'] = 'Titulo';
$_['description'] = 'Descripcion';
$_['point_of_sale'] = "Punto de venta domiati";
$_['testnet'] = "Activar testnet";
 
$_['entry_status'] = 'Estatus:';
$_['entry_order_status'] = 'Orden del estatus:';
 
$_['help'] = 'Punto de venta creado en tu cuenta de domitai';

$_['text_button_save'] = 'Guardar';
$_['text_button_cancel'] = 'Cancelar';
?>