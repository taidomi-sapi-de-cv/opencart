<?php
// Text
$_['text_title'] = 'Bitcoin and cryptocurrencies';
$_['select_text'] = 'Cryptocurrency';
$_['title_address'] = 'Address';
$_['scan'] = 'Scan';
$_['qr_text'] = 'QR Code';
$_['get_address'] = 'to get address';
$_['error_currency'] = 'Your currency symbol is not valid, please communicate with the admin page';
