<?php
// Text
$_['text_title'] = 'Bitcoin y criptomonedas';
$_['select_text'] = 'Criptomoneda';
$_['title_address'] = 'Dirección';
$_['scan'] = 'Escanear';
$_['qr_text'] = 'Codigo QR';
$_['get_address'] = 'para obtener la dirección';
$_['error_currency'] = 'El simbolo de la divisa seleccionada es invalido, favor de comunicarse con el administrador del sitio';
